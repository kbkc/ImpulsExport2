namespace ImpulsExport
{
	internal class Anschrift
	{
		public string Vorname;

		public string Nachname;

		public string TIN;

		public string Strasse;

		public string Ort;

		public string PLZ;

		public string Land;
	}
}
